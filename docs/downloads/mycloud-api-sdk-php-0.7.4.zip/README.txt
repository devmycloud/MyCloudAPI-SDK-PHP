To use in your code:
   1) copy the "vendor" directory into your PHP code.
   2) require_once('path_to_vendor_directory/autoload.php');
   3) make API calls
   
Examples:
   The directory "vendor/mycloudth/rest-api-sdk-php/examples" contains
   PHP programs that will run "out of the box". There is one example
   for every possible API call you can make.
   
   The examples come with a default sdk_config.ini file that uses an
   apiKey tied to a demo account. You will need to signup with MyCloud
   to get an apiKey that will provide you access to your account.

   To run an example:
   
      1) cd vendor/mycloudth/rest-api-sdk-php/examples
	  2) php _example_program_.php  (e.g.  php get_product_list.php)
